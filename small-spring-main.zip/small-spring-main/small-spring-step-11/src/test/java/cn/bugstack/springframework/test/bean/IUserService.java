package cn.bugstack.springframework.test.bean;

public interface IUserService {

    String queryUserInfo();

    String register(String userName);
}
